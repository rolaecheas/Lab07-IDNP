package com.example.lab07_fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class RojoFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    EditText editText;
    Button boton;
    TextView textView;

    public RojoFragment() {
    }


    public static RojoFragment newInstance(String param1, String param2) {
        RojoFragment fragment = new RojoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View main= inflater.inflate(R.layout.fragment_rojo, container, false);

        editText=(EditText) main.findViewById(R.id.edt1);
        boton=(Button) main.findViewById(R.id.btn1);


        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView= (TextView) getActivity().findViewById(R.id.txv1);
                textView.setText(editText.getText().toString());
            }
        });
        return main;
    }
}