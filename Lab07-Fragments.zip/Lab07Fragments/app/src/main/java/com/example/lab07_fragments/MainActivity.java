package com.example.lab07_fragments;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity  {

    private Toolbar toolbar1;
    private BottomNavigationView bottomNavigationView1;
    FragmentTransaction transaction;
    Fragment fragmentInicio, fragmentRojo, fragmentverde, fragmentNegro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        toolbar1=findViewById(R.id.toolbar);
        bottomNavigationView1=findViewById(R.id.bottomNavView);
        toolbar1.setTitle("Fragmento Inicial activo");

        setSupportActionBar(toolbar1);

        fragmentInicio=new InicioFragment();
        fragmentRojo= new RojoFragment();
        fragmentverde=new VerdeFragment();
        fragmentNegro= new NegroFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.framerojo,fragmentRojo).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.frameverde,fragmentverde).commit();

        bottomNavigationView1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.menuFragmento1:
                        getSupportFragmentManager().beginTransaction().replace(R.id.framerojo,new RojoFragment()).commit();
                        toolbar1.setTitle("Fragemento Rojo activo");
                        return true;
                    case R.id.menuFragmento2:
                        getSupportFragmentManager().beginTransaction().replace(R.id.framerojo,new VerdeFragment()).commit();
                        toolbar1.setTitle("Fragemento Verde activo");
                        return true;

                    case R.id.menuFragmento3:
                        getSupportFragmentManager().beginTransaction().replace(R.id.framerojo,new NegroFragment()).commit();
                        toolbar1.setTitle("Fragemento Negro activo");
                        return true;

                }
                return false;
            }
        });

    }





}